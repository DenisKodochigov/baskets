package com.example.shopping_list.ui.products_basket

import androidx.compose.runtime.Composable

@Composable
fun ProductsBasketScreen(basketId: String, onClickProduct: (String) -> Unit = {}){

}