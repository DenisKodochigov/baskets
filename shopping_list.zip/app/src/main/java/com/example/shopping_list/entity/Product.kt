package com.example.shopping_list.entity

data class Product (
    val name: String? = null,
    val value: Double? = null,
)