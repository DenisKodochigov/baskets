package com.example.shopping_list.ui.components

import androidx.compose.runtime.Composable

@Composable
fun BottomBar() {

}

