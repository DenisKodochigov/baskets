package com.example.shopping_list.ui.products

import androidx.compose.runtime.Composable

@Composable
fun ProductsScreen(onClickProduct: (String) -> Unit = {}){

}