//Row(
//Modifier.fillMaxWidth()
//) {
//    Column(
//        modifier = Modifier
//            .padding(14.dp)
//            .background(Color.Gray),
//        horizontalAlignment = Alignment.CenterHorizontally) {
//        Icon(imageVector = Icons.Filled.Settings, contentDescription = "Settings",
//            modifier = Modifier.background(Color.Gray))
//        Text( "ICON 1111111111", color = Color.White, style = textBottomBar)
//    }
//    Column(
//        modifier = Modifier
//            .padding(14.dp)
//            .background(Color.Blue),
//        horizontalAlignment = Alignment.CenterHorizontally) {
//        Icon(imageVector = Icons.Filled.Settings, contentDescription = "Settings",
//            modifier = Modifier.background(Color.Blue))
//        Text( "ICON 2222222222", color = Color.White, style = textBottomBar)
//    }
//    Spacer(modifier = Modifier.weight(1f))
//    Column(
//        modifier = Modifier
//            .padding(14.dp)
//            .background(Color.Green),
//        horizontalAlignment = Alignment.CenterHorizontally
//    ) {
//        Icon(imageVector = Icons.Filled.Settings, contentDescription = "Settings",
//            modifier = Modifier.background(Color.Green))
//        Text( "ICON 3333333333", color = Color.White, style = textBottomBar,)
//    }
//}